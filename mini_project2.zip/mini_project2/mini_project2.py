### Utility Functions
import pandas as pd
import sqlite3
from sqlite3 import Error
from datetime import datetime
import csv


def create_connection(db_file, delete_db=False):
    import os
    if delete_db and os.path.exists(db_file):
        os.remove(db_file)

    conn = None
    try:
        conn = sqlite3.connect(db_file)
        conn.execute("PRAGMA foreign_keys = 1")
    except Error as e:
        print(e)

    return conn



def insert_table(conn, values,sql_stmnt):
        # sql_stmnt = "insert into Region(Region) values(?)"
        cur = conn.cursor()
        cur.executemany(sql_stmnt, values)
        return cur.lastrowid

def create_table(conn, create_table_sql, drop_table_name=None):
    
    if drop_table_name: # You can optionally pass drop_table_name to drop the table. 
        try:
            c = conn.cursor()
            c.execute("""DROP TABLE IF EXISTS %s""" % (drop_table_name))
        except Error as e:
            print(e)
    
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e)
        
def execute_sql_statement(sql_statement, conn):
    cur = conn.cursor()
    cur.execute(sql_statement)

    rows = cur.fetchall()

    return rows



def step1_create_region_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None
    
    ### BEGIN SOLUTION
    initial_strip_split = []
    with open(data_filename, 'r') as file:
        for line in file:
            strip=line.strip('\n')
            split=strip.split('\t')
            initial_strip_split.append(split)
    initial_strip_split.pop(0)
    n_let = [initial_strip_split[i][4] for i in range(len(initial_strip_split))]
    remove_duplicates = []
    [remove_duplicates.append(x) for x in n_let if x not in remove_duplicates]
    remove_duplicates.sort()
    temp=[]
    for sub in remove_duplicates:
        temp.append(tuple(sub.split(', ')))
    print(temp)
    conn = create_connection(normalized_database_filename)
    create = """CREATE TABLE Region  (
                                        [RegionID] INTEGER NOT NULL primary key,
                                        [Region] TEXT NOT NULL
                                    );"""
    with conn:
        create_table(conn, create,drop_table_name='Region') 
        cur = conn.cursor()
        cur.executemany("INSERT INTO Region(Region) VALUES(?)", tuple(temp))
        return cur.lastrowid
    ### END SOLUTION

def step2_create_region_to_regionid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)   
    sql_statement = "SELECT * FROM Region"   
    region_data = execute_sql_statement(sql_statement, conn)   
    region_dicto={} 
    for i,j in enumerate(region_data):
        region_dicto[j[1]]=i+1
    return region_dicto
    ### END SOLUTION


def step3_create_country_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None
    
    ### BEGIN SOLUTION
    
    initial_strip_split = []
    with open(data_filename, 'r') as file:
        for line in file:
            strip=line.strip('\n')
            split=strip.split('\t')
            initial_strip_split.append(split)
    initial_strip_split.pop(0)
    new_list=[]
    for i in range(len(initial_strip_split)):
        new_list.append([initial_strip_split[i][3],initial_strip_split[i][4]])
    remove_duplicates = []
    [remove_duplicates.append(x) for x in new_list if x not in remove_duplicates]
    remove_duplicates.sort()
    region_id=step2_create_region_to_regionid_dictionary(normalized_database_filename)
    for country_list in remove_duplicates:
        if country_list[1] in region_id:
            country_list[1]=region_id[country_list[1]]
    tuples = [tuple(x) for x in remove_duplicates]
    conn = create_connection(normalized_database_filename)
    create = """CREATE TABLE Country  (
                                        [CountryID] INTEGER NOT NULL Primary key AUTOINCREMENT,
                                        [Country] TEXT NOT NULL,
                                        [RegionID] INTEGER NOT NULL
                                        );"""

    with conn:
        create_table(conn, create,drop_table_name='Country') 
        cur = conn.cursor()
        cur.executemany("INSERT INTO Country(Country,RegionID) values(?,?)", tuple(tuples))
        return cur.lastrowid
         
    ### END SOLUTION


def step4_create_country_to_countryid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)   
    sql_statement = "SELECT * FROM Country"   
    Country_data = execute_sql_statement(sql_statement, conn)   
    Country_dicto={} 
    for i,j in enumerate(Country_data):
        Country_dicto[j[1]]=i+1
    return Country_dicto

    ### END SOLUTION
        
        
def step5_create_customer_table(data_filename, normalized_database_filename):

    ### BEGIN SOLUTION
    
    initial_strip_split = []
    with open(data_filename, 'r') as file:
        for line in file:
            strip=line.strip('\n')
            split=strip.split('\t')
            initial_strip_split.append(split)
    initial_strip_split.pop(0)
    new_list=[]
    for i in range(len(initial_strip_split)):
        temp_split=initial_strip_split[i][0].split(" ",1)
        # q=temp_split[1:]
        new_list.append([temp_split[0],temp_split[1],initial_strip_split[i][1],initial_strip_split[i][2],initial_strip_split[i][3]])
    remove_duplicates = []
    [remove_duplicates.append(x) for x in new_list if x not in remove_duplicates]
    remove_duplicates.sort()
    # print(remove_duplicates)
    country_id=step4_create_country_to_countryid_dictionary(normalized_database_filename)
    for country_list in remove_duplicates:
        if country_list[-1] in country_id:
            country_list[-1]=country_id[country_list[-1]]
    conn = create_connection(normalized_database_filename)
    create = """CREATE TABLE Customer (
                                        [CustomerID] INTEGER NOT NULL Primary Key,
                                        [FirstName] TEXT NOT NULL,
                                        [LastName] TEXT NOT NULL,
                                        [Address] TEXT NOT NULL,
                                        [City] TEXT NOT NULL,
                                        [CountryID] INTEGER NOT NULL 
                                        );"""
    with conn:
        create_table(conn, create,drop_table_name='Customer') 
        cur = conn.cursor()
        cur.executemany("insert into Customer(FirstName,LastName, Address, City, CountryID) values(?,?,?,?,?)", tuple(remove_duplicates))
        return cur.lastrowid

# # normalized_database_filename = 'normalized.db'
# # data_filename = 'data.csv'
# # step5_create_customer_table(
# #     data_filename, normalized_database_filename)
# # data = pd.read_csv("step5.csv")

# with open('file.csv', 'r') as file:
#     my_reader = csv.reader(file, delimiter=',')
#     for row in my_reader:
#         print(row)
# # conn = create_connection(normalized_database_filename)
# # df = pd.read_sql_query("""SELECT * FROM Customer""", conn)
# # print(df)
# # print(data)

# # given = df['LastName'].values
# # ours = data['LastName'].values
# # # m_last = given.equals(ours)

# # if df.equals(data) == True:
# #     print("111")
# # else:
# #     print("***")
#     ### END SOLUTION

def step6_create_customer_to_customerid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)   
    sql_statement = "SELECT * FROM Customer"   
    Customer_data = execute_sql_statement(sql_statement, conn)   
    Customer_dicto={} 
    for i,j in enumerate(Customer_data):
        Customer_dicto[j[1]+" "+j[2]]=i+1
    return Customer_dicto

#     ### END SOLUTION
        
def step7_create_productcategory_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None
    ### BEGIN SOLUTION
    initial_strip_split = []
    with open(data_filename, 'r') as file:
        for line in file:
            strip=line.strip('\n')
            split=strip.split('\t')
            initial_strip_split.append(split)
    initial_strip_split.pop(0)
    temp =[]
    for i in range(len(initial_strip_split)):
        temp.append([initial_strip_split[i][6],initial_strip_split[i][7]])
    pro_catagory,pro_description = temp[0][0].split(';'),temp[0][1].split(';')
    temp1=[]
    for i in range(len(pro_catagory)):
        temp1.append([pro_catagory[i],pro_description[i]])
    remove_duplicates = []
    [remove_duplicates.append(x) for x in temp1 if x not in remove_duplicates]
    remove_duplicates.sort()
    conn = create_connection(normalized_database_filename)
    create_table_product_category= """CREATE TABLE ProductCategory (
                                                                    [ProductCategoryID] INTEGER NOT NULL Primary Key,
                                                                    [ProductCategory] TEXT NOT NULL,
                                                                    [ProductCategoryDescription] TEXT NOT NULL
                                                                    );"""
    with conn:
        create_table(conn, create_table_product_category,drop_table_name='ProductCategory') 
        cur = conn.cursor()
        cur.executemany("insert into ProductCategory(ProductCategory, ProductCategoryDescription) values(?,?)", tuple(remove_duplicates))
        return cur.lastrowid
    
    
#     ### END SOLUTION

def step8_create_productcategory_to_productcategoryid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)   
    sql_statement = "SELECT * FROM ProductCategory"   
    ProductCategory_data = execute_sql_statement(sql_statement, conn)   
    ProductCategory_dicto={} 
    for i,j in enumerate(ProductCategory_data):
        ProductCategory_dicto[j[1]]=i+1
    return ProductCategory_dicto

#     ### END SOLUTION
        

def step9_create_product_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None
    ### BEGIN SOLUTION
    initial_strip_split = []
    catid = []
    temp =[]
    temp_list=[]
    with open(data_filename, 'r') as file:
        for line in file:
            strip=line.strip('\n')
            split=strip.split('\t')
            initial_strip_split.append(split)
    initial_strip_split.pop(0)
    for i in range(len(initial_strip_split)):
        temp.append([initial_strip_split[i][5],initial_strip_split[i][8],initial_strip_split[i][6]])
    ProductName,ProductUnitPrice,ProductCategoryID = temp[0][0].split(';'), temp[0][1].split(';'), temp[0][2].split(';') 
    ProductCategory_id=step8_create_productcategory_to_productcategoryid_dictionary(normalized_database_filename)
    for id in range(len(ProductCategoryID)):
        catid.append(ProductCategory_id.get(ProductCategoryID[id]))
    for i in range(len(ProductName)):
        temp_list.append([ProductName[i],ProductUnitPrice[i],catid[i]])
    remove_duplicates = []
    [remove_duplicates.append(x) for x in temp_list if x not in remove_duplicates]
    remove_duplicates.sort()
    create = """CREATE TABLE Product (
                                        [ProductID] INTEGER NOT NULL Primary Key,
                                        [ProductName] TEXT NOT NULL,
                                        [ProductUnitPrice] REAL NOT NULL,
                                        [ProductCategoryID] INTEGER NOT NULL ,
                                        FOREIGN KEY(ProductCategoryID) REFERENCES ProductCategory(ProductCategoryID)
                                     );"""
    conn = create_connection(normalized_database_filename)
    with conn:
        create_table(conn, create,drop_table_name='Product') 
        cur = conn.cursor()
        cur.executemany("insert into Product(ProductName, ProductUnitPrice, ProductCategoryID) values(?,?,?)", tuple(remove_duplicates))
        return cur.lastrowid
    ### END SOLUTION


def step10_create_product_to_productid_dictionary(normalized_database_filename):
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)   
    sql_statement = "SELECT * FROM Product"   
    Product_data = execute_sql_statement(sql_statement, conn)   
    Product_dicto={} 
    for i,j in enumerate(Product_data):
        Product_dicto[j[1]]=i+1
    return Product_dicto

#     ### END SOLUTION
        

def step11_create_orderdetail_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None

    
    ### BEGIN SOLUTION
        
    productid_id = step10_create_product_to_productid_dictionary(normalized_database_filename)
    customerid_id = step6_create_customer_to_customerid_dictionary(normalized_database_filename)
    order_list = []
    initial_strip_split=[]
    with open(data_filename, 'r') as file:
        for line in file:
            strip=line.strip('\n')
            split=strip.split('\t')
            initial_strip_split.append(split)
    initial_strip_split.pop(0)
    for split in initial_strip_split:
        product_name_split = split[0]
        product_split = split[5]
        quantity_split = split[9]
        date_split = split[10]
        product_split=product_split.split(';')
        quantity_split=quantity_split.split(';')
        date_split=date_split.split(';')
        zip_file=zip(product_split, quantity_split, date_split)
        for pro_split, quantity_split, ord_date_split in zip_file: 
            ord_date_split = datetime.strptime(ord_date_split.strip(), '%Y%m%d').strftime('%Y-%m-%d')
            order_list.append([customerid_id[product_name_split], productid_id[pro_split], ord_date_split ,quantity_split])
    create = '''CREATE TABLE OrderDetail (
                                [OrderID] INTEGER NOT NULL PRIMARY KEY, 
                                [CustomerID] INTEGER NOT NULL ,
                                [ProductID] INTEGER NOT NULL ,
                                [OrderDate] INTEGER NOT NULL, 
                                [QuantityOrdered] INTEGER NOT NULL
                                )'''
    conn = create_connection(normalized_database_filename)
    with conn:
        create_table(conn, create,drop_table_name='OrderDetail')
        cur = conn.cursor()
        cur.executemany("INSERT INTO OrderDetail(CustomerID, ProductID, OrderDate,QuantityOrdered) VALUES (?,?,?,?);", order_list)
        return cur.lastrowid
    ### END SOLUTION


def ex1(conn, CustomerName):
    
#     # Simply, you are fetching all the rows for a given CustomerName. 
#     # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer and Product table.
#     # Pull out the following columns. 
#     # Name -- concatenation of FirstName and LastName
#     # ProductName
#     # OrderDate
#     # ProductUnitPrice
#     # QuantityOrdered
#     # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- round to two decimal places
#     # HINT: USE customer_to_customerid_dict to map customer name to customer id and then use where clause with CustomerID
    
#     ### BEGIN SOLUTION
    sql_statement = f"""SELECT Customer.FirstName||' '|| Customer.LastName AS Name, 
                            Product.ProductName,
                            OrderDetail.OrderDate, 
                            ROUND(Product.ProductUnitPrice, 2) AS ProductUnitPrice,
                            OrderDetail.QuantityOrdered,
                            ROUND(OrderDetail.QuantityOrdered*Product.ProductUnitPrice, 2) AS Total 
                            FROM OrderDetail INNER JOIN Customer ON Customer.CustomerID = OrderDetail.CustomerID
                            INNER JOIN Product ON Product.ProductID = OrderDetail.ProductID 
                            WHERE Name = '{CustomerName}' ; """
    
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex2(conn, CustomerName):
    
    # Simply, you are summing the total for a given CustomerName. 
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer and Product table.
    # Pull out the following columns. 
    # Name -- concatenation of FirstName and LastName
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round to two decimal places
    # HINT: USE customer_to_customerid_dict to map customer name to customer id and then use where clause with CustomerID
    
    ### BEGIN SOLUTION

    sql_statement = f"""SELECT Customer.FirstName||' '|| Customer.LastName AS Name,
                        ROUND(SUM(OrderDetail.QuantityOrdered*Product.ProductUnitPrice), 2) AS Total 
                        FROM OrderDetail  JOIN Customer ON Customer.CustomerID = OrderDetail.CustomerID
                        JOIN Product ON Product.ProductID = OrderDetail.ProductID 
                        WHERE Name = '{CustomerName}' ; """ 



    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex3(conn):
    
    # Simply, find the total for all the customers
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer and Product table.
    # Pull out the following columns. 
    # Name -- concatenation of FirstName and LastName
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round to two decimal places
    # ORDER BY Total Descending 
    ### BEGIN SOLUTION
    sql_statement = """SELECT Customer.FirstName||' '|| Customer.LastName AS Name,
                        ROUND(SUM(OrderDetail.QuantityOrdered*Product.ProductUnitPrice), 2) AS Total 
                        FROM OrderDetail
                        JOIN Customer ON Customer.CustomerID = OrderDetail.CustomerID
                        JOIN Product ON Product.ProductID = OrderDetail.ProductID  
                        GROUP BY Name 
                        ORDER BY Total DESC ;
    
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex4(conn):
    
    # Simply, find the total for all the region
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer, Product, Country, and 
    # Region tables.
    # Pull out the following columns. 
    # Region
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round to two decimal places
    # ORDER BY Total Descending 
    ### BEGIN SOLUTION

    sql_statement = """SELECT Region,
                        ROUND(SUM(Product.ProductUnitPrice * OrderDetail.QuantityOrdered), 2) as Total 
                        FROM OrderDetail 
                        NATURAL JOIN Product
                        NATURAL JOIN Customer  
                        NATURAL JOIN Country
                        NATURAL JOIN Region 
                        GROUP BY Region 
                        ORDER BY Total DESC """ 
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex5(conn):
    
     # Simply, find the total for all the countries
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer, Product, and Country table.
    # Pull out the following columns. 
    # Country
    # CountryTotal -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round
    # ORDER BY Total Descending 
    ### BEGIN SOLUTION

    sql_statement = """SELECT Country, 
                        ROUND(SUM(P.ProductUnitPrice * OD.QuantityOrdered)) as CountryTotal
                        FROM OrderDetail OD
                        NATURAL JOIN Product  P
                        NATURAL JOIN Customer 
                        NATURAL JOIN Country 
                        NATURAL JOIN Region 
                        GROUP BY Country 
                        ORDER BY CountryTotal DESC;
                    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement


def ex6(conn):
    
    # Rank the countries within a region based on order total
    # Output Columns: Region, Country, CountryTotal, CountryRegionalRank
    # Hint: Round the the total
    # Hint: Sort ASC by Region
    ### BEGIN SOLUTION

    sql_statement = """SELECT Region, Country, CountryTotal,
                    RANK () OVER (PARTITION BY Region
                                  ORDER BY CountryTotal DESC) CountryRegionalRank 
                    FROM(SELECT Region,Country, ROUND(SUM(Product.ProductUnitPrice * OrderDetail.QuantityOrdered)) as CountryTotal
                    FROM OrderDetail
                    NATURAL JOIN Product 
                    NATURAL JOIN customer 
                    NATURAL JOIN Country 
                    NATURAL JOIN Region 
                    GROUP BY Country)
                    ORDER BY Region ASC
     
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement



def ex7(conn):
    
   # Rank the countries within a region based on order total, BUT only select the TOP country, meaning rank = 1!
    # Output Columns: Region, Country, CountryTotal, CountryRegionalRank
    # Hint: Round the the total
    # Hint: Sort ASC by Region
    # HINT: Use "WITH"
    ### BEGIN SOLUTION

    sql_statement = """
      
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

# def ex8(conn):
    
#     # Sum customer sales by Quarter and year
#     # Output Columns: Quarter,Year,CustomerID,Total
#     # HINT: Use "WITH"
#     # Hint: Round the the total
#     # HINT: YOU MUST CAST YEAR TO TYPE INTEGER!!!!
#     ### BEGIN SOLUTION

#     sql_statement = """
       
#     """
#     ### END SOLUTION
#     df = pd.read_sql_query(sql_statement, conn)
#     return sql_statement

# def ex9(conn):
    
#     # Rank the customer sales by Quarter and year, but only select the top 5 customers!
#     # Output Columns: Quarter, Year, CustomerID, Total
#     # HINT: Use "WITH"
#     # Hint: Round the the total
#     # HINT: YOU MUST CAST YEAR TO TYPE INTEGER!!!!
#     # HINT: You can have multiple CTE tables;
#     # WITH table1 AS (), table2 AS ()
#     ### BEGIN SOLUTION

#     sql_statement = """
    
#     """
#     ### END SOLUTION
#     df = pd.read_sql_query(sql_statement, conn)
#     return sql_statement

# def ex10(conn):
    
#     # Rank the monthy sales
#     # Output Columns: Quarter, Year, CustomerID, Total
#     # HINT: Use "WITH"
#     # Hint: Round the the total
#     ### BEGIN SOLUTION

#     sql_statement = """
      
#     """
#     ### END SOLUTION
#     df = pd.read_sql_query(sql_statement, conn)
#     return sql_statement

# def ex11(conn):
    
#     # Find the MaxDaysWithoutOrder for each customer 
#     # Output Columns: 
#     # CustomerID,
#     # FirstName,
#     # LastName,
#     # Country,
#     # OrderDate, 
#     # PreviousOrderDate,
#     # MaxDaysWithoutOrder
#     # order by MaxDaysWithoutOrder desc
#     # HINT: Use "WITH"; I created two CTE tables
#     # HINT: Use Lag

#     ### BEGIN SOLUTION

#     sql_statement = """
     
#     """
#     ### END SOLUTION
#     df = pd.read_sql_query(sql_statement, conn)
#     return sql_statement