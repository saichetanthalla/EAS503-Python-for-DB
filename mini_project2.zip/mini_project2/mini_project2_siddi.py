### Utility Functions
import pandas as pd
import sqlite3
from sqlite3 import Error

def create_connection(db_file, delete_db=False):
    import os
    if delete_db and os.path.exists(db_file):
        os.remove(db_file)

    conn = None
    try:
        conn = sqlite3.connect(db_file)
        conn.execute("PRAGMA foreign_keys = 1")
    except Error as e:
        print(e)

    return conn


def create_table(conn, create_table_sql, drop_table_name=None):
    
    if drop_table_name: # You can optionally pass drop_table_name to drop the table. 
        try:
            c = conn.cursor()
            c.execute("""DROP TABLE IF EXISTS %s""" % (drop_table_name))
        except Error as e:
            print(e)
    
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e)
        
def execute_sql_statement(sql_statement, conn):
    cur = conn.cursor()
    cur.execute(sql_statement)

    rows = cur.fetchall()

    return rows

def step1_create_region_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None
    
    ### BEGIN SOLUTION

    with open(data_filename, "r") as file:
        lines = file.readlines()
        region_list = []
        for i in range(1, len(lines)):
            lines_list= lines[i].split("\t")
            region = lines_list[4]
            if region not in region_list:
                region_list.append(region)
        region_list.sort()
        region_id = 1
        final_list = []    
        for i in region_list:
            final_list.append([region_id,i])
            region_id +=1

    create_statement = """CREATE TABLE REGION ([RegionID] Integer not null primary key AUTOINCREMENT,[Region] Text not null);"""
    insert_statement = """INSERT INTO REGION ([RegionID], [Region])VALUES (?,?);"""

    conn = create_connection(normalized_database_filename)

    with conn:
        create_table(conn,create_statement)
        cur = conn.cursor()
        for i in final_list:
            cur.execute(insert_statement, i)
    ### END SOLUTION

def step2_create_region_to_regionid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)
    sql = "Select * from Region"
    rows = execute_sql_statement(sql, conn)
    region_dict = {row[1]:row[0] for row in rows}
    return region_dict


    ### END SOLUTION


def step3_create_country_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None
    
    ### BEGIN SOLUTION
    
    with open(data_filename, "r") as file:
        lines = file.readlines()
        country_dict = {}
        for i in range(1, len(lines)):
            lines_list= lines[i].split("\t")
            country = lines_list[3]
            region = lines_list[4]
            if country not in country_dict.keys():
                country_dict[country]=region
        final_dict = dict(sorted(country_dict.items(), key =lambda kv:(kv[0])))
        country_id = 1
        region_dict = step2_create_region_to_regionid_dictionary(normalized_database_filename)
        final_list = []
        for key, value in final_dict.items():
            if value in region_dict.keys():
                final_list.append([country_id, key, region_dict[value]])
            country_id+=1

    create_statement = "CREATE TABLE COUNTRY ( [CountryID] integer not null Primary key, [Country] Text not null,[RegionID] integer not null,FOREIGN KEY(RegionID) REFERENCES REGION(RegionID));"
    insert_statement = "INSERT INTO COUNTRY VALUES (?,?,?);"

    conn = create_connection(normalized_database_filename)

    with conn:
        create_table(conn,create_statement)
        cur = conn.cursor()
        for i in final_list:
            cur.execute(insert_statement, i)
         
    ### END SOLUTION


def step4_create_country_to_countryid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
        conn = create_connection(normalized_database_filename)
        sql = "Select * from COUNTRY"
        rows = execute_sql_statement(sql, conn)
        country_dict = {row[1]:row[0] for row in rows}
        return country_dict

    ### END SOLUTION
        
        
def step5_create_customer_table(data_filename, normalized_database_filename):

    ### BEGIN SOLUTION
    
    with open("data.csv", "r") as file:
        lines = file.readlines()
    country_dict = {}
    final_list = []
    CustomerID = 1
    for i in range(1, len(lines)):
        lines_list= lines[i].split("\t")
        FirstName, LastName = lines_list[0].split(" ",1)
        Address = lines_list[1]
        City = lines_list[2]
        Country = lines_list[3]  
        country_dict = step4_create_country_to_countryid_dictionary('normalized.db')
        CountryID = country_dict.get(Country)


        final_list.append([CustomerID,FirstName, LastName, Address, City, CountryID])
    final_list = sorted(final_list, key=lambda x: (x[1], x[2]))

    for i in final_list:
        i[0] = CustomerID
        CustomerID +=1

    #CustomerID, FirstName, LastName, Address, City, CountryID
    create_statement = "CREATE TABLE customer ( [CustomerID] integer not null Primary key, [FirstName] Text not null, [LastName] Text, [Address] Text, [City] Text, [CountryID] integer not null);"
    insert_statement = "INSERT INTO customer VALUES (?,?,?,?,?,?);"

    conn = create_connection(normalized_database_filename)

    with conn:
        create_table(conn,create_statement)
        cur = conn.cursor()
        for i in final_list:
            cur.execute(insert_statement, i)


    ### END SOLUTION


def step6_create_customer_to_customerid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)
    sql = "Select FirstName || ' ' || LastName AS fullname, CustomerID from customer"
    rows = execute_sql_statement(sql, conn)  
    customer_dict = {row[0]:row[1] for row in rows}
    return customer_dict


    ### END SOLUTION
        
def step7_create_productcategory_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None

    
    ### BEGIN SOLUTION
    with open("data.csv", "r") as file:
        lines = file.readlines()
    ProductCategoryID = 1
    final_list = []
    temp_list = []
    for i in range(1, len(lines)):
        lines_list= lines[i].split("\t")
        ProductCategory = lines_list[6]
        ProductCategoryDescription = lines_list[7]
        for category, description in zip(ProductCategory.split(';'), ProductCategoryDescription.split(';')):
            if category not in temp_list:
                temp_list.append(category)
                final_list.append([ProductCategoryID,category,description])
    
    final_list = sorted(final_list, key=lambda x: (x[1]))

    for i in final_list:
        i[0] = ProductCategoryID
        ProductCategoryID +=1
    print(final_list)

    create_statement = "CREATE TABLE ProductCategory ( [ProductCategoryID] integer not null Primary key, [ProductCategory] Text not null, [ProductCategoryDescription] Text no null);"
    insert_statement = "INSERT INTO ProductCategory VALUES (?,?,?);"

    conn = create_connection(normalized_database_filename)

    with conn:
        create_table(conn,create_statement)
        cur = conn.cursor()
        for i in final_list:
            cur.execute(insert_statement, i)
   
    ### END SOLUTION

def step8_create_productcategory_to_productcategoryid_dictionary(normalized_database_filename):
    
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)
    sql = "Select ProductCategory,ProductCategoryID from ProductCategory"
    rows = execute_sql_statement(sql, conn)
    product_dict = {row[0]:row[1] for row in rows}
    return product_dict


    ### END SOLUTION
        

def step9_create_product_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None

    
    ### BEGIN SOLUTION
    
    with open('data.csv') as file:
        lines = file.readlines()
    product_list = []
    temp_list = []
    ProductID = 1
    for i in range(1, len(lines)):
        line = lines[i].split("\t")    
        ProductName = line[5]
        Product_price= line[8]
        Product_cat = line[6]

        prod_dict = step8_create_productcategory_to_productcategoryid_dictionary(normalized_database_filename)
        for name,price,prodcat in zip(ProductName.split(';'), Product_price.split(';'), Product_cat.split(';')):
            if prodcat in prod_dict:
                if name not in temp_list:
                    temp_list.append(name)
                    price = str(round((float(price)),2))
                    product_list.append([ProductID,name,price, prod_dict[prodcat]])

    product_list = sorted(product_list, key=lambda x: (x[1]))

    for i in product_list:
        i[0] = ProductID
        ProductID +=1
    #print(product_list)


    create_statement = "CREATE TABLE Product ([ProductID] integer not null Primary key, [ProductName] Text not null,[ProductUnitPrice] Real not null,[ProductCategoryID] integer not null,FOREIGN KEY(ProductCategoryID) REFERENCES ProductCategory(ProductCategoryID));"
    insert_statement = "INSERT INTO Product VALUES (?,?,?,?);"

    conn = create_connection(normalized_database_filename)

    with conn:
        create_table(conn,create_statement)
        cur = conn.cursor()
        for i in product_list:
            cur.execute(insert_statement, i)

    
    ### END SOLUTION


def step10_create_product_to_productid_dictionary(normalized_database_filename):
    
    ### BEGIN SOLUTION
    conn = create_connection(normalized_database_filename)
    sql = "Select ProductID,ProductName from Product"
    rows = execute_sql_statement(sql, conn)
    productname_dict = {row[1]:row[0] for row in rows}
    return productname_dict

    ### END SOLUTION
        

def step11_create_orderdetail_table(data_filename, normalized_database_filename):
    # Inputs: Name of the data and normalized database filename
    # Output: None

    
    ### BEGIN SOLUTION
    from datetime import datetime
    strptime = datetime.strptime

    with open('data.csv') as file:
        lines = file.readlines()
    order_list = []
    temp_list = []
    OrderID = 1
    for i in range(1, len(lines)):
        line = lines[i].split("\t") 
        name = line[0]
        prod = line[5]

        Qty_Orderded = line[9]
        Order_Date= line[10]
        
        prodid_dict = step10_create_product_to_productid_dictionary(normalized_database_filename)

        custid_dict = step6_create_customer_to_customerid_dictionary(normalized_database_filename)
        for prod_name,QuantityOrderded,OrderDate in zip(prod.split(';'),Qty_Orderded.split(';'), Order_Date.split(';')):
            if name in custid_dict:
                if prod_name in prodid_dict:
                    OrderDate = OrderDate.strip()
                    try:
                        OrderDate = strptime(OrderDate, '%Y%m%d').strftime('%Y-%m-%d')
                    except:
                            continue
                    QuantityOrderded = int(QuantityOrderded)
                    order_list.append([OrderID,custid_dict[name], prodid_dict[prod_name], OrderDate ,QuantityOrderded])


    for i in order_list:
        i[0] = OrderID
        OrderID +=1


    create_statement = "CREATE TABLE OrderDetail ([OrderID] integer not null Primary Key, [CustomerID] integer not null ,[ProductID] integer not null ,[OrderDate] integer not null, [QuantityOrdered] integer not null);"
    insert_statement = "INSERT INTO OrderDetail VALUES (?,?,?,?,?);"

    conn = create_connection(normalized_database_filename)

    with conn:
        create_table(conn,create_statement)
        cur = conn.cursor()
        cur.executemany(insert_statement, order_list)
        ### END SOLUTION


def ex1(conn, CustomerName):
    
    # Simply, you are fetching all the rows for a given CustomerName. 
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer and Product table.
    # Pull out the following columns. 
    # Name -- concatenation of FirstName and LastName
    # ProductName
    # OrderDate
    # ProductUnitPrice
    # QuantityOrdered
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- round to two decimal places
    # HINT: USE customer_to_customerid_dict to map customer name to customer id and then use where clause with CustomerID
    
    ### BEGIN SOLUTION
    dict1 = step6_create_customer_to_customerid_dictionary('normalized.db')
    for k,v in dict1.items():
        if k == CustomerName:
            custid = v
            break
    sql_statement = ( """select c.FirstName || " " || c.LastName as Name,
                         p.ProductName, o.OrderDate,
                          p.ProductUnitPrice, o.QuantityOrdered ,
                             round(p.ProductUnitPrice*o.QuantityOrdered,2) as Total from OrderDetail o 
                             JOIN Product p ON o.ProductID=p.ProductID JOIN customer c 
                             ON o.CustomerID=c.CustomerID where c.CustomerID = '%s';""" % custid )
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex2(conn, CustomerName):
    
    # Simply, you are summing the total for a given CustomerName. 
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer and Product table.
    # Pull out the following columns. 
    # Name -- concatenation of FirstName and LastName
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round to two decimal places
    # HINT: USE customer_to_customerid_dict to map customer name to customer id and then use where clause with CustomerID
    
    ### BEGIN SOLUTION
    dict1 = step6_create_customer_to_customerid_dictionary('normalized.db')
    for k,v in dict1.items():
        if k == CustomerName:
            custid = v
            break
    sql_statement = ( """select c.FirstName || " " || c.LastName as Name,round(sum(p.ProductUnitPrice*o.QuantityOrdered),2) as Total from OrderDetail o JOIN Product p ON o.ProductID=p.ProductID JOIN customer c ON o.CustomerID=c.CustomerID where c.CustomerID = '%s' group by Name;""" % custid )


    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex3(conn):
    
    # Simply, find the total for all the customers
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer and Product table.
    # Pull out the following columns. 
    # Name -- concatenation of FirstName and LastName
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round to two decimal places
    # ORDER BY Total Descending 
    ### BEGIN SOLUTION
    sql_statement = """select c.FirstName || " " || c.LastName as Name,round(sum(p.ProductUnitPrice*o.QuantityOrdered),2) as Total from OrderDetail o JOIN Product p ON o.ProductID=p.ProductID JOIN customer c ON o.CustomerID=c.CustomerID  group by Name ORDER BY Total desc;"""
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex4(conn):
    
    # Simply, find the total for all the region
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer, Product, Country, and 
    # Region tables.
    # Pull out the following columns. 
    # Region
    # Total -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round to two decimal places
    # ORDER BY Total Descending 
    ### BEGIN SOLUTION

    sql_statement ="""select r.Region,round(sum(p.ProductUnitPrice*o.QuantityOrdered),2) as Total from OrderDetail o JOIN Product p ON o.ProductID=p.ProductID JOIN customer c ON o.CustomerID=c.CustomerID  JOIN Country ct ON  c.CountryID = ct.CountryID JOIN Region r ON r.RegionID=ct.RegionID GROUP BY Region ORDER BY Total desc
"""
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex5(conn):
    
     # Simply, find the total for all the countries
    # Write an SQL statement that SELECTs From the OrderDetail table and joins with the Customer, Product, and Country table.
    # Pull out the following columns. 
    # Country
    # CountryTotal -- which is calculated from multiplying ProductUnitPrice with QuantityOrdered -- sum first and then round
    # ORDER BY Total Descending 
    ### BEGIN SOLUTION

    sql_statement = """select ct.Country, round(sum(p.ProductUnitPrice*o.QuantityOrdered),2) as Total from OrderDetail o JOIN Product p ON o.ProductID=p.ProductID JOIN customer c ON o.CustomerID=c.CustomerID  JOIN Country ct ON  c.CountryID = ct.CountryID JOIN Region r ON r.RegionID=ct.RegionID GROUP BY Country ORDER BY Total desc
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement


def ex6(conn):
    
    # Rank the countries within a region based on order total
    # Output Columns: Region, Country, CountryTotal, CountryRegionalRank
    # Hint: Round the the total
    # Hint: Sort ASC by Regions
    ### BEGIN SOLUTION

    sql_statement = """select r.Region, ct.Country, round(sum(p.ProductUnitPrice*o.QuantityOrdered),2) as Total, ROW_NUMBER() OVER(PARTITION BY r.Region ORDER BY Total) CountryRegionalRank from OrderDetail o JOIN Product p ON o.ProductID=p.ProductID JOIN customer c ON o.CustomerID=c.CustomerID  JOIN Country ct ON  c.CountryID = ct.CountryID JOIN Region r ON r.RegionID=ct.RegionID GROUP BY Country ORDER BY r.Region asc
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement



def ex7(conn):
    
   # Rank the countries within a region based on order total, BUT only select the TOP country, meaning rank = 1!
    # Output Columns: Region, Country, CountryTotal, CountryRegionalRank
    # Hint: Round the the total
    # Hint: Sort ASC by Region
    # HINT: Use "WITH"
    ### BEGIN SOLUTION

    sql_statement = """
      
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex8(conn):
    
    # Sum customer sales by Quarter and year
    # Output Columns: Quarter,Year,CustomerID,Total
    # HINT: Use "WITH"
    # Hint: Round the the total
    # HINT: YOU MUST CAST YEAR TO TYPE INTEGER!!!!
    ### BEGIN SOLUTION

    sql_statement = """
       
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex9(conn):
    
    # Rank the customer sales by Quarter and year, but only select the top 5 customers!
    # Output Columns: Quarter, Year, CustomerID, Total
    # HINT: Use "WITH"
    # Hint: Round the the total
    # HINT: YOU MUST CAST YEAR TO TYPE INTEGER!!!!
    # HINT: You can have multiple CTE tables;
    # WITH table1 AS (), table2 AS ()
    ### BEGIN SOLUTION

    sql_statement = """
    
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex10(conn):
    
    # Rank the monthy sales
    # Output Columns: Quarter, Year, CustomerID, Total
    # HINT: Use "WITH"
    # Hint: Round the the total
    ### BEGIN SOLUTION

    sql_statement = """
      
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement

def ex11(conn):
    
    # Find the MaxDaysWithoutOrder for each customer 
    # Output Columns: 
    # CustomerID,
    # FirstName,
    # LastName,
    # Country,
    # OrderDate, 
    # PreviousOrderDate,
    # MaxDaysWithoutOrder
    # order by MaxDaysWithoutOrder desc
    # HINT: Use "WITH"; I created two CTE tables
    # HINT: Use Lag

    ### BEGIN SOLUTION

    sql_statement = """
     
    """
    ### END SOLUTION
    df = pd.read_sql_query(sql_statement, conn)
    return sql_statement